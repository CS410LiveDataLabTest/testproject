# naive_bayes.py
# ---------------
# Licensing Information:  You are free to use or extend this projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to the University of Illinois at Urbana-Champaign
#
# Created by Justin Lizama (jlizama2@illinois.edu) on 09/28/2018
# Last Modified 8/23/2023


"""
This is the main code for this MP.
You only need (and should) modify code within this file.
Original staff versions of all other files will be used by the autograder
so be careful to not modify anything else.
"""


import reader
import math
from tqdm import tqdm
from collections import Counter
import nltk
import numpy as np

nltk.download('stopwords')
from nltk.corpus import stopwords

'''
util for printing values
'''
def print_values(laplace, pos_prior):
    print(f"Unigram Laplace: {laplace}")
    print(f"Positive prior: {pos_prior}")

"""
load_data loads the input data by calling the provided utility.
You can adjust default values for stemming and lowercase, when we haven't passed in specific values,
to potentially improve performance.
"""

def load_data(trainingdir, testdir, stemming=True, lowercase=True, silently=False):
    print(f"Stemming: {stemming}")
    print(f"Lowercase: {lowercase}")
    train_set, train_labels, dev_set, dev_labels = reader.load_dataset(trainingdir,testdir,stemming,lowercase,silently)
    #print(len(train_set),len(train_labels))
    #print(len(dev_set),len(dev_labels))
    return train_set, train_labels, dev_set, dev_labels

'''
utility function using ntlk for removing stop words
'''
def removeStopWords(data):
    
    stop_words = set(stopwords.words('english'))
    #print((data[0]))
    updated_data=[]
    for i in range(len(data)):
        temp=[]
        for word in data[i]:
            if word not in stop_words:
                temp.append(word)
        updated_data.append(temp)
    #print((updated_data[0]))
    return updated_data

'''
function for returning the bag of words model
input: trainig dataset, training labels and either 0 or 1 as flag to indicate negative or positive sentiment
output: bag of words dictionary
'''
def bagOfWords(data, labels, flag):
    
    tot_word_ct = {} #the bag of words dictionary where the key is the word and the value represents how many times it is encountered

    for ct in range(len(labels)):
        if (labels[ct] != flag):
            continue
        temp_list = data[ct]
        for word in temp_list:
            if word in tot_word_ct:
                tot_word_ct[word] += 1
            else:
                tot_word_ct[word] = 1
    #print(tot_word_ct)
    return tot_word_ct

'''
'''
def handleUnknownProbability(tot_word_ct, alpha):

    assigned_prob = {}
    words = 0
    tot_types = len(tot_word_ct)
    for word in tot_word_ct:
        words += tot_word_ct[word]
    unkown_prob = alpha/(words + alpha*(tot_types))
    for word in tot_word_ct:
        prob = (tot_word_ct[word] + alpha)/(words + alpha*(tot_types))
        assigned_prob[word] = prob

    return assigned_prob, unkown_prob 

"""
Main function for training and predicting with naive bayes.
    You can modify the default values for the Laplace smoothing parameter and the prior for the positive label.
    Notice that we may pass in specific values for these parameters during our testing.
"""
def naiveBayes(dev_set, train_set, train_labels, laplace=5.5, pos_prior=0.8, silently=False):
    #removing stop words from the training dataset
    #removeStopWords(train_set)

    print_values(laplace,pos_prior)

    positive_ct = bagOfWords(train_set, train_labels, 1)
    negative_ct = bagOfWords(train_set, train_labels, 0)
    positive_ct,p_unknown = handleUnknownProbability(positive_ct, laplace)
    negative_ct,n_unknown = handleUnknownProbability(negative_ct, laplace)
    log_p_unkown = math.log(p_unknown)
    log_n_unkown = math.log(n_unknown)

    yhats = []

    for l in dev_set:
        p = 0
        n = 0

        for word in l:
            if word in positive_ct:
                p += math.log(positive_ct[word])
            else:
                p += log_p_unkown

            if word in negative_ct:
                n += math.log(negative_ct[word])
            else:
                n += log_n_unkown
        p += math.log(pos_prior)
        n += math.log(1-pos_prior)

        if (p > n):
            yhats.append(1)
        else:
            yhats.append(0)

    '''for doc in tqdm(dev_set, disable=silently):
        yhats.append(-1)
    '''
    return yhats
